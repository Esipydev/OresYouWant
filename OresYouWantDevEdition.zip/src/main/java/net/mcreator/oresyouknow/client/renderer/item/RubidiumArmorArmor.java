package net.mcreator.oresyouknow.client.renderer.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.resources.model.EquipmentClientInfo;

import net.mcreator.oresyouknow.init.OresYouKnowModItems;
import net.mcreator.oresyouknow.init.OresYouKnowModArmorModels;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class RubidiumArmorArmor {
	public static void clientLoad() {
		OresYouKnowModArmorModels.ARMOR_MODELS.put(OresYouKnowModItems.RUBIDIUM_ARMOR_HELMET, new OresYouKnowModArmorModels.ArmorModel() {
			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation _default) {
				return ResourceLocation.parse("ores_you_know:textures/models/armor/realrubidium_layer_1.png");
			}
		});
		OresYouKnowModArmorModels.ARMOR_MODELS.put(OresYouKnowModItems.RUBIDIUM_ARMOR_CHESTPLATE, new OresYouKnowModArmorModels.ArmorModel() {
			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation _default) {
				return ResourceLocation.parse("ores_you_know:textures/models/armor/realrubidium_layer_1.png");
			}
		});
		OresYouKnowModArmorModels.ARMOR_MODELS.put(OresYouKnowModItems.RUBIDIUM_ARMOR_LEGGINGS, new OresYouKnowModArmorModels.ArmorModel() {
			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation _default) {
				return ResourceLocation.parse("ores_you_know:textures/models/armor/realrubidium_layer_2.png");
			}
		});
		OresYouKnowModArmorModels.ARMOR_MODELS.put(OresYouKnowModItems.RUBIDIUM_ARMOR_BOOTS, new OresYouKnowModArmorModels.ArmorModel() {
			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation _default) {
				return ResourceLocation.parse("ores_you_know:textures/models/armor/realrubidium_layer_1.png");
			}
		});
	}
}